<?php include '../app/views/layout/header.php'; ?>

<h1>Selamat datang di halaman beranda</h1>

<?php include '../app/views/layout/footer.php'; ?>