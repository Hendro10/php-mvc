</main>

<!-- Footer situs -->
<footer>
    &copy; <?php echo date('Y'); ?> Contoh Aplikasi MVC
</footer>
</body>
</html>
