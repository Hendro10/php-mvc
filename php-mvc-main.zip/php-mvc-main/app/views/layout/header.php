<!DOCTYPE html>
<html>
<head>
    <title>Contoh Aplikasi MVC</title>
    <!-- File-file CSS dan JavaScript -->
    <link rel="stylesheet" href="/public/css/style.css">
    <script src="/public/js/script.js"></script>
</head>
<body>
    <!-- Header situs -->
    <header>
        <h1>Contoh Aplikasi MVC</h1>
    </header>

    <!-- Menu navigasi, jika ada -->

    <!-- Konten utama -->
    <main>
