<?php
echo("<hr>");
echo("<center>Opps... Halaman yang dicari bermasalah</center>");
die();