<?php include '../app/views/layout/header.php'; ?>

<!-- Konten halaman "Tentang Kami" atau "Tentang Aplikasi" -->
<h1>Tentang Kami</h1>

<?php include '../app/views/layout/footer.php'; ?>
