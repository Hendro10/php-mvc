<?php

class HomeController {
    public function index() {
        
        include '../app/views/home/index.php';
    }
}

